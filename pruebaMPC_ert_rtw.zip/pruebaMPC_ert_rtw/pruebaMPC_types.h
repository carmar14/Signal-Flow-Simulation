/*
 * File: pruebaMPC_types.h
 *
 * Code generated for Simulink model 'pruebaMPC'.
 *
 * Model version                  : 1.4
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Thu Sep 13 11:19:58 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pruebaMPC_types_h_
#define RTW_HEADER_pruebaMPC_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_pruebaMPC_T RT_MODEL_pruebaMPC_T;

#endif                                 /* RTW_HEADER_pruebaMPC_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
