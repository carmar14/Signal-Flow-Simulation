function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["pruebaj2.c:123c47"]=1;
    this.traceFlag["pruebaj2.c:127c24"]=1;
    this.traceFlag["pruebaj2.c:160c29"]=1;
    this.traceFlag["pruebaj2.c:160c32"]=1;
    this.traceFlag["pruebaj2.c:161c29"]=1;
    this.traceFlag["pruebaj2.c:165c29"]=1;
    this.traceFlag["pruebaj2.c:165c32"]=1;
    this.traceFlag["pruebaj2.c:166c29"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["pruebaj2.c:120"]=1;
    this.lineTraceFlag["pruebaj2.c:123"]=1;
    this.lineTraceFlag["pruebaj2.c:126"]=1;
    this.lineTraceFlag["pruebaj2.c:127"]=1;
    this.lineTraceFlag["pruebaj2.c:159"]=1;
    this.lineTraceFlag["pruebaj2.c:160"]=1;
    this.lineTraceFlag["pruebaj2.c:161"]=1;
    this.lineTraceFlag["pruebaj2.c:164"]=1;
    this.lineTraceFlag["pruebaj2.c:165"]=1;
    this.lineTraceFlag["pruebaj2.c:166"]=1;
    this.lineTraceFlag["pruebaj2.c:226"]=1;
    this.lineTraceFlag["pruebaj2.c:229"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
