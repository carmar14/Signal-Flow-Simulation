function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/Step */
	this.urlHashMap["pruebaj:305"] = "pruebaj.c:121&pruebaj.h:55";
	/* <Root>/VSI  line Z1 */
	this.urlHashMap["pruebaj:302"] = "pruebaj.c:117,153,213&pruebaj.h:60,65,70";
	/* <Root>/Out1 */
	this.urlHashMap["pruebaj:304"] = "pruebaj.c:116&pruebaj.h:86";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "pruebaj"};
	this.sidHashMap["pruebaj"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/Step"] = {sid: "pruebaj:305"};
	this.sidHashMap["pruebaj:305"] = {rtwname: "<Root>/Step"};
	this.rtwnameHashMap["<Root>/VSI  line Z1"] = {sid: "pruebaj:302"};
	this.sidHashMap["pruebaj:302"] = {rtwname: "<Root>/VSI  line Z1"};
	this.rtwnameHashMap["<Root>/Out1"] = {sid: "pruebaj:304"};
	this.sidHashMap["pruebaj:304"] = {rtwname: "<Root>/Out1"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
